package backend.hobbiebackend.model.entities.enums;

public enum LocationEnum {
    BANGALORE,
    CHENNAI,
    HYDERABAD,
    DELHI,
    MYSORE
}
